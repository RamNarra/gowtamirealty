import json,sys,glob,subprocess
rows=[]
for f in sys.argv[1:]:
    a=json.loads(subprocess.run(["python3","analyze_run.py",f],capture_output=True,text=True).stdout)
    d=json.load(open(f))
    ptok=sum((t['prompt_tokens_reported'] or 0) for t in a['turns']); ctok=sum(ex['response'].get('usage',{}).get('completion_tokens',0) for ex in d['exchanges'] if 'usage' in ex['response'])
    fact_tok=sum(t['sample_fact_tokens_visible'] for t in a['turns'])
    rows.append({"run":f.replace('run_','').replace('.json',''),"status":a['status'],"risk":a['risk'],"hyp":a['hypotheses'],
      "traj":[(t[0],t[1].get('pattern') or t[1].get('target_class') or t[1].get('algorithm') or t[1].get('operation') or '',t[2]) for t in a['tool_trajectory']],
      "facts_computed":a['facts_computed_total'],"facts_visible":a['facts_ever_visible_to_model'],"prompt_tok":ptok,"completion_tok":ctok,"fact_tok_in_prompts":fact_tok,
      "wall":d['wall_s'],"turns":len(a['turns']),"stop":[s for s in a['supervisor'] if s[0]!='TOOL_CALL_REJECTED'],
      "final_text":(a['turns'][-1]['output'] if a['turns'] else '')[:200]})
for r in rows: print(json.dumps(r))
