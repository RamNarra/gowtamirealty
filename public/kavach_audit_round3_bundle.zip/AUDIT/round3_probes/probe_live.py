"""Audit round 3: end-to-end service runs with full model-boundary capture.

usage: probe_live.py <sample_path> <mode: agent|fixed> <out.json> [max_turns]
  agent: real llama-server at 127.0.0.1:8092 (KAVACH_LLAMA_BASE_URL default)
  fixed: scripted deterministic tool sequence through the same service/controller/tools
"""
import asyncio, json, os, sys, time, tempfile, shutil
from pathlib import Path
sys.path.insert(0, os.getcwd())
import httpx

from agent.controller import InvestigationController
from intelligence.capabilities import MODEL_PROFILES
from intelligence.gateway import ModelGateway
from intelligence.provider import LlamaCppReasoningProvider
from ledger import InvestigationLedger
from service.investigations import InvestigationService
from service.runs import MemoryRunRepository
from storage.store import ArtifactStore
from tools.registry import build_demo_tool_registry, ToolRegistry
from service_testing import ScriptedLlamaServer, tool_turn, text_turn

sample, mode, out_path = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
max_turns = int(sys.argv[4]) if len(sys.argv) > 4 else 8
SP = Path(__file__).parent
EXCH = []          # model request/response pairs
RAW = []           # every tool execution: full raw_data the model never sees


class RecordingTransport(httpx.AsyncBaseTransport):
    def __init__(self):
        self.inner = httpx.AsyncHTTPTransport()

    async def handle_async_request(self, request):
        body = json.loads(request.content)
        t0 = time.time()
        try:
            resp = await self.inner.handle_async_request(request)
        except Exception as ex:
            EXCH.append({"request": body, "response": {"error": repr(ex)}, "wall_s": 0}); raise
        data = await resp.aread()
        EXCH.append({"request": body, "response": json.loads(data), "wall_s": round(time.time() - t0, 2)})
        return httpx.Response(resp.status_code, headers=resp.headers, content=data)


class ScriptRecorder(ScriptedLlamaServer):
    def handler(self, request):
        r = super().handler(request)
        EXCH.append({"request": json.loads(request.content), "response": json.loads(r.content), "wall_s": 0})
        return r


_orig = ToolRegistry.execute_tool
async def _wrapped(self, raw_input, context):
    out = await _orig(self, raw_input, context)
    RAW.append({"input": raw_input, "status": out.status.value, "summary": out.output_summary,
                "raw_data": json.loads(json.dumps(out.raw_data, default=str)),
                "evidence": [(e.type, e.severity.value, e.origin.value) for e in out.new_evidence]})
    return out
ToolRegistry.execute_tool = _wrapped
if mode == "fixed_nocap":
    from agent.supervisor import InvestigationManager as _S
    _S.check_diminishing_returns = lambda self, inv: None

FIXED = [  # deterministic analyst-style sequence using the same tool set
    tool_turn(("inspect_container", {"artifact_id": "artifact://original_apk"})),
    tool_turn(("search_strings", {"artifact_id": "artifact://original_apk", "pattern": r"https?://[A-Za-z0-9./_-]+", "is_regex": True, "max_results": 50})),
    tool_turn(("search_strings", {"artifact_id": "artifact://original_apk", "pattern": "DexClassLoader"})),
    tool_turn(("search_strings", {"artifact_id": "artifact://original_apk", "pattern": "Runtime"})),
    tool_turn(("find_xrefs", {"artifact_id": "artifact://original_apk", "target_class": "dalvik.system.DexClassLoader"})),
    tool_turn(("find_xrefs", {"artifact_id": "artifact://original_apk", "target_class": "android.telephony.SmsManager"})),
    tool_turn(("run_jadx", {"artifact_id": "artifact://original_apk"})),
    text_turn("Fixed sequence complete."),
]


async def main():
    work = Path(tempfile.mkdtemp(prefix="live_", dir=SP))
    store = ArtifactStore.create_filesystem_store(work / "cas")
    ledger = InvestigationLedger()
    runs = MemoryRunRepository()
    if mode == "agent":
        provider = LlamaCppReasoningProvider(base_url=os.environ.get("KAVACH_LLAMA_BASE_URL", "http://127.0.0.1:8092/v1"),
                                             transport=RecordingTransport())
    elif mode.startswith("script:"):
        raw = json.load(open(mode[7:]))
        provider = ScriptRecorder([tool_turn(*[(c[0], c[1]) for c in t]) if t else text_turn("done") for t in raw]).provider()
    else:
        provider = ScriptRecorder(list(FIXED)).provider()

    def factory(st, led):
        return InvestigationController(ModelGateway(provider, MODEL_PROFILES["qwen3.5-4b"]), build_demo_tool_registry(),
                                       artifact_store=st, ledger=led)
    svc = InvestigationService(store=store, ledger=ledger, runs=runs, controller_factory=factory,
                               work_root=work / "work", max_turns=max_turns, max_seconds=1500)
    t0 = time.time()
    rec = await svc.create(sample.read_bytes(), sample.name)
    await svc.wait(rec.run_id)
    wall = time.time() - t0
    report = await svc.report(rec.run_id)
    events = await svc.events(rec.run_id)
    arts = await svc.artifacts(rec.run_id)
    out = {"sample": str(sample), "mode": mode, "wall_s": round(wall, 1), "report": report,
           "events": [e.model_dump(mode="json") for e in events], "exchanges": EXCH, "tool_raw": RAW,
           "artifacts": [a.model_dump(mode="json") for a in arts]}
    out_path.write_text(json.dumps(out, indent=1, default=str))
    shutil.rmtree(work, ignore_errors=True)
    print(rec.run_id, report["investigation"]["status"], report["final"]["risk_level"], report["final"]["risk_score"], f"{wall:.0f}s",
          "turns", report["investigation"]["turn_count"], "calls", report["investigation"]["tool_calls"])

asyncio.run(main())
