"""Per-turn model-boundary accounting for a probe_live.py output.

Content classes (by message):
  STATIC      system prompt, tool schemas, supervisor notices (sample-independent)
  STATUS      tool messages / initial observation text that is counts, statuses, handles, guidance
  CONTENT     sample-derived facts actually visible to the model (strings, URLs, class/method names,
              entry names, manifest values) -- measured by substring presence of raw_data facts.
Tokens via llama-server /tokenize when reachable, else chars/4.
"""
import json, sys, re, urllib.request
from collections import Counter

d = json.load(open(sys.argv[1]))


def ntok(text):
    try:
        req = urllib.request.Request("http://127.0.0.1:8092/tokenize", data=json.dumps({"content": text}).encode(),
                                     headers={"Content-Type": "application/json"})
        return len(json.loads(urllib.request.urlopen(req, timeout=10).read())["tokens"])
    except Exception:
        return len(text) // 4


# all sample-derived facts the tools computed (what an analyst would want to read)
facts = set()
for r in d["tool_raw"]:
    rd = r["raw_data"]
    for m in rd.get("matches", []) or []:
        facts.add(m.get("matched_string", "")); facts.add(m.get("source_entry", ""))
    for c in (rd.get("callers", []) or []) + (rd.get("callees", []) or []):
        for k in ("caller_class", "caller_method", "callee_class", "callee_method"):
            if c.get(k): facts.add(c[k])
    for k in ("dex_files", "anomalies"):
        for v in rd.get(k, []) or []:
            facts.add(str(v))
facts = {f for f in facts if f and len(f) >= 6}

turns = []
for i, ex in enumerate(d["exchanges"], 1):
    req, resp = ex["request"], ex["response"]
    msgs = req["messages"]
    cats = Counter()
    visible = ""
    for m in msgs:
        c = m.get("content") or ""
        if m["role"] == "system":
            cats["STATIC_system"] += ntok(c)
        elif m["role"] == "user" and c.startswith("[SUPERVISOR"):
            cats["STATIC_supervisor"] += ntok(c)
        elif m["role"] == "user":
            cats["STATUS_initial_or_frontier"] += ntok(c); visible += c
        elif m["role"] == "tool":
            cats["STATUS_tool_observation"] += ntok(c); visible += c
        elif m["role"] == "assistant":
            cats["MODEL_own_text"] += ntok(c + json.dumps(m.get("tool_calls", [])))
    cats["STATIC_tool_schemas"] = ntok(json.dumps(req.get("tools", [])))
    seen = [f for f in facts if f in visible]
    content_tok = sum(ntok(f) for f in seen)
    msg = resp["choices"][0]["message"]
    turns.append({
        "turn": i, "prompt_tokens_reported": resp.get("usage", {}).get("prompt_tokens"),
        "categories": dict(cats), "sample_fact_tokens_visible": content_tok,
        "facts_visible": len(seen), "facts_computed_so_far": len(facts),
        "tool_calls": [(tc["function"]["name"], tc["function"]["arguments"][:160]) for tc in msg.get("tool_calls", []) or []],
        "output": (msg.get("content") or "")[:600], "reasoning": (msg.get("reasoning_content") or "")[:400],
        "finish": resp["choices"][0].get("finish_reason"), "wall_s": ex["wall_s"],
    })

ev = d["events"]
summary = {
    "sample": d["sample"], "mode": d["mode"], "wall_s": d["wall_s"],
    "status": d["report"]["investigation"]["status"], "risk": (d["report"]["final"]["risk_level"], d["report"]["final"]["risk_score"]),
    "key_findings": d["report"]["final"]["key_findings"],
    "hypotheses": [(h["claim_type"], h["status"]) for h in d["report"]["hypotheses"]],
    "tool_trajectory": [(r["input"]["tool"], {k: v for k, v in r["input"].items() if k not in ("tool", "artifact_id")}, r["status"]) for r in d["tool_raw"]],
    "facts_computed_total": len(facts),
    "facts_ever_visible_to_model": len({f for f in facts if any(f in json.dumps(ex["request"]["messages"]) for ex in d["exchanges"])}),
    "supervisor": [(e["payload"]["decision_type"], e["payload"]["action"]) for e in ev if e["event_type"] == "SUPERVISOR_DECISION"],
    "turns": turns,
}
print(json.dumps(summary, indent=1))
