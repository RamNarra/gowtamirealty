"""Two service instances sharing one run repository + ledger (what two API replicas on one PostgreSQL do)."""
import asyncio, json, os, sys, tempfile
from pathlib import Path
sys.path.insert(0, os.getcwd())
import httpx
from ledger import InvestigationLedger, EventType
from ledger.chain import verify_chain
from service.runs import MemoryRunRepository
from storage.store import ArtifactStore
from service_testing import ScriptedLlamaServer, build_service, tool_turn, text_turn

SP = Path(__file__).parent
SAMPLE = Path("/home/p4cketsn1ff3r/Projects/Active/APKs_and_Mobile_Security/selendroid-test-app.apk")


class SlowServer(ScriptedLlamaServer):
    async def ahandler(self, request):
        await asyncio.sleep(0.4)
        return self.handler(request)

    def provider(self):
        from intelligence.provider import LlamaCppReasoningProvider
        return LlamaCppReasoningProvider(base_url="http://llama.test/v1", transport=httpx.MockTransport(self.ahandler))


def script():
    return [tool_turn(("inspect_container", {"artifact_id": "artifact://original_apk"})),
            tool_turn(("search_strings", {"artifact_id": "artifact://original_apk", "pattern": "http"})),
            text_turn("done")]


async def main():
    out = {}
    work = Path(tempfile.mkdtemp(dir=SP))
    store = ArtifactStore.create_filesystem_store(work / "cas")
    ledger, runs = InvestigationLedger(), MemoryRunRepository()
    a = build_service(SlowServer(script()), store, ledger, runs, work / "a")
    b = build_service(SlowServer(script()), store, ledger, runs, work / "b")
    rec = await a.create(SAMPLE.read_bytes(), "x.apk")
    await asyncio.sleep(0.6)
    out["b_recover_closed"] = await b.recover_interrupted()
    await a.wait(rec.run_id)
    evs = await ledger.events(rec.run_id)
    fins = [(e.sequence, e.payload.get("status")) for e in evs if e.event_type == EventType.RUN_FINALIZED]
    first_fin = fins[0][0] if fins else None
    out["finalizations"] = fins
    out["events_after_first_finalize"] = sum(1 for e in evs if first_fin and e.sequence > first_fin)
    out["verify_valid"] = verify_chain(evs).valid
    out["row_status"] = (await runs.get(rec.run_id)).status
    rep = await a.report(rec.run_id)
    out["report_status"] = rep["investigation"]["status"]
    out["report_risk"] = (rep["final"]["risk_level"], rep["final"]["risk_score"])

    # same sample submitted twice concurrently: two independent runs, duplicated CAS write, no idempotency key
    s2 = build_service(ScriptedLlamaServer([text_turn("done")] * 4), store, ledger, runs, work / "c")
    r1, r2 = await asyncio.gather(s2.create(SAMPLE.read_bytes(), "x.apk"), s2.create(SAMPLE.read_bytes(), "x.apk"))
    await asyncio.gather(s2.wait(r1.run_id), s2.wait(r2.run_id))
    out["same_sample_twice"] = {"distinct_runs": r1.run_id != r2.run_id, "same_sha": r1.sample_sha256 == r2.sample_sha256,
                                "statuses": [(await runs.get(r.run_id)).status for r in (r1, r2)]}

    # concurrent report reads during a run (read-your-writes / consistency)
    s3 = build_service(SlowServer(script()), store, ledger, runs, work / "d")
    r3 = await s3.create(SAMPLE.read_bytes(), "x.apk")
    snaps = []
    for _ in range(6):
        rp = await s3.report(r3.run_id)
        snaps.append((rp["investigation"]["status"], rp["final"]["risk_level"], rp["final"]["ledger_verification"]["valid"]))
        await asyncio.sleep(0.3)
    await s3.wait(r3.run_id)
    out["report_while_running"] = snaps
    (SP / "probe_race.json").write_text(json.dumps(out, indent=1, default=str))
    print(json.dumps(out, indent=1, default=str))

asyncio.run(main())
