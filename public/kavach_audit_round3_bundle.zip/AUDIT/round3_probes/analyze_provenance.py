"""Claim -> hypothesis -> evidence -> artifact -> execution -> tool call -> input artifact graph for one run."""
import json, sys

d = json.load(open(sys.argv[1]))
rep, evs = d["report"], d["events"]
arts = {a["artifact_id"]: a for a in d["artifacts"]}
execs = {e["payload"]["execution_id"]: e["payload"] for e in evs if e["event_type"] == "EXECUTION_COMPLETED"}
calls = {e["payload"]["tool_call_id"]: e["payload"] for e in evs if e["event_type"] == "TOOL_CALLED"}
evidence = {e["payload"]["id"]: e["payload"] for e in evs if e["event_type"] == "EVIDENCE_ASSERTED"}

edges, rows = [], []
for eid, p in evidence.items():
    checks = {}
    if p.get("baseline"):
        checks = {"baseline_triage_no_execution_record": True}
    else:
        x = execs.get(p.get("source_execution_id") or "")
        c = calls.get(p.get("source_tool_call_id") or "")
        checks["artifact_exists"] = p.get("source_artifact_id") in arts
        checks["execution_exists"] = x is not None
        checks["tool_call_exists"] = c is not None
        checks["execution_bound_to_call"] = bool(x and x.get("tool_call_id") == p.get("source_tool_call_id"))
        checks["execution_input_is_source_artifact"] = bool(x and any(i["artifact_id"] == p.get("source_artifact_id") for i in x.get("input_artifacts", [])))
        checks["evidence_value_is_execution_output"] = bool(x and any(o["sha256"] == p.get("normalized_value") for o in x.get("output_artifacts", [])))
        checks["execution_status_success"] = bool(x and x.get("status") == "SUCCESS")
        checks["tool_isolated"] = bool(x and x.get("effective_isolation") not in ("NONE", None))
    rows.append({"evidence": eid[:8], "type": p["type"], "severity": p["severity"], "checks": checks,
                 "complete": all(checks.values()) and not p.get("baseline")})

hyps = []
for h in rep["hypotheses"]:
    ev = evidence.get(h.get("resolved_by_evidence_id") or "")
    hyps.append({"claim": h["claim_type"], "status": h["status"], "summary": h["claim_summary"][:80],
                 "has_evidence": ev is not None,
                 # semantic binding: is the confirming artifact derived from the entry the hypothesis names?
                 "evidence_derived_from_named_entry": False if ev else None})

claims = []
for k in rep["final"]["key_findings"]:
    claims.append({"claim": k, "kind": "key_finding"})
claims.append({"claim": rep["final"]["risk_summary"], "kind": "risk_summary"})
complete = sum(r["complete"] for r in rows)
summary = {
    "evidence_total": len(rows), "evidence_full_provenance": complete,
    "evidence_baseline_without_execution": sum(1 for r in rows if "baseline_triage_no_execution_record" in r["checks"]),
    "evidence_from_failed_or_inconclusive_execution": sum(1 for r in rows if r["checks"].get("execution_exists") and not r["checks"].get("execution_status_success")),
    "evidence_from_unisolated_execution": sum(1 for r in rows if r["checks"].get("execution_exists") and not r["checks"].get("tool_isolated")),
    "rows": rows, "hypotheses": hyps, "claims": claims,
}
print(json.dumps(summary, indent=1))
